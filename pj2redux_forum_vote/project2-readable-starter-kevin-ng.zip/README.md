# Readable Project by Kevin Ng

A simple react forum app that can make posts, comments and vote.
You can post in different provided topics. Make as many comments as you wish.


## Installation

1. After you downloaded the folder zip file. You can use npm install to download the necessary node-packages

2. Then, you can use the npm start to launch the app.


## Contributing

This repository is created by Kevin Ng from Udacity React Class starter tamplate. Sole purpose for submitting Project 2 - Readable project  


